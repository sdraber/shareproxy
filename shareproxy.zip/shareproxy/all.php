<?php
$channel = "-1001455505736";
if($msg and $chatID == -1001395363861){
if(preg_match("/^(server:) (.*)\n(port:) (.*)\n(secret:) (.*)\n(.*)$/i", $msg, $preg)){
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@shareproxybot", 'peer' => $channel, 'query' => "$preg[2] $preg[4] $preg[6] @MegaTm", 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $channel, 'query_id' => $query_id, 'id' => $query_res_id, ]);
}
}
?>

